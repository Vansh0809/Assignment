package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelSmallAppPageFactory {

	WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfusname;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfuspassword;
	
	@FindBy(xpath=".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
    @CacheLookup
    WebElement pfbutton;



	public WebElement getPfusname() {
		return pfusname;
	}

	public void setPfusname(String susname) {
		pfusname.sendKeys(susname);
	}

	public WebElement getPfuspassword() {
		return pfuspassword;
	}

	public void setPfuspassword(String suspassword) {
		pfuspassword.sendKeys(suspassword);
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public void setPfbutton() {
		pfbutton.click();
	}
	
	public HotelSmallAppPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
}
