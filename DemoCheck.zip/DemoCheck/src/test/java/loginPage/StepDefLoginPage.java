package loginPage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.HotelBookingPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLoginPage {

	private WebDriver driver;
	private HotelBookingPageFactory objhbpg;
	
	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\VANSH\\Desktop\\Module 3\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new HotelBookingPageFactory(driver);
		driver.get("file:///D:/Users/VANSH/Desktop/Module%203/App/login.html");
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("")) 
		    System.out.println("****** Title Matched");
		else 
			System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}


	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		objhbpg.setPfusname("capgemini");
	Thread.sleep(1000);
	objhbpg.setPfuspassword("capg1234");
	Thread.sleep(1000);
	
	objhbpg.setPfbutton();
	
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("file:///D:/Users/VANSH/Desktop/Module%203/App/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user leaves username blank$")
	public void user_leaves_username_blank() throws Throwable {
		objhbpg.setPfusname("");	
		Thread.sleep(1000);
		objhbpg.setPfuspassword("capg1234");
		Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		objhbpg.setPfbutton();
	}

	@Then("^display ualert msg$")
public void display_ualert_msg() throws Throwable {
   String userAlert=driver.findElement(By.id("userErrMsg")).getText();
   Thread.sleep(1000);
System.out.println("*******"+ userAlert);
	driver.close();
	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Throwable {
		objhbpg.setPfusname("capgemini");
		Thread.sleep(1000);
		objhbpg.setPfuspassword("");	
		Thread.sleep(1000);
		objhbpg.setPfbutton();

	}
@Then("^display palert msg$")
public void display_palert_msg() throws Throwable {
	String passAlert=driver.findElement(By.id("pwdErrMsg")).getText();
	   Thread.sleep(1000);
	System.out.println("*******"+ passAlert);
		driver.close();
}

@When("^user enters incorrect username and password and clicks the button$")
public void user_enters_incorrect_username_and_password_and_clicks_the_button() throws Throwable {
   objhbpg.setPfusname("vansh");
   Thread.sleep(1000);
   objhbpg.setPfuspassword("1234");
   Thread.sleep(1000);
   objhbpg.setPfbutton(); 
}



@Then("^display alert msg$")
public void display_alert_msg() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
    driver.close();
}
}
