package bookingwebdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Driver {

	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\VANSH\\Desktop\\Module 3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("file:///D:/Users/VANSH/Desktop/Module%203/App/hotelbooking.html");
	
		   
		   driver.findElement(By.name("txtFN")).sendKeys("Vansh");
		   Thread.sleep(2000);
		   driver.findElement(By.name("txtLN")).sendKeys("Arora");
		   Thread.sleep(2000);
		   driver.findElement(By.name("Email")).sendKeys("vansh.arora@gmail.com");
		   Thread.sleep(2000);
		   driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("8755629058");
		   Thread.sleep(2000);
		   driver.findElement(By.name("city")).sendKeys("Pune");
		   Thread.sleep(2000);
		   driver.findElement(By.name("state")).sendKeys("Maharashtra");
		   Thread.sleep(2000);
		   driver.findElement(By.name("persons")).sendKeys("4");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtCardholderName")).sendKeys("Vansh Arora");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtDebit")).sendKeys("1234 5678 9876 4321");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtCvv")).sendKeys("888");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtMonth")).sendKeys("12");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtYear")).sendKeys("25");
		   Thread.sleep(2000);
		   driver.findElement(By.id("btnPayment")).click();
		   Thread.sleep(2000);
		   callalert();
		   Thread.sleep(2000);
		   driver.quit();
		   Thread.sleep(2000);
		   }
	public static void callalert() throws InterruptedException
	{
		
		String alertmsg=driver.switchTo().alert().getText();
		System.out.println(alertmsg);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

		 driver.close();
	}
}
