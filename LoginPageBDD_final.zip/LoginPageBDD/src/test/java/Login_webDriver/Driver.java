package Login_webDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Driver {
static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\VANSH\\Desktop\\Module 3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("file:///D:/Users/VANSH/Desktop/Module%203/App/login.html");

		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(2000);
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(2000);
		 callalert();
		 Thread.sleep(2000);
		 driver.quit();
	}
	 public static void callalert() throws InterruptedException
		{
			
			String alertmsg=driver.switchTo().alert().getText();
			System.out.println(alertmsg);
			driver.switchTo().alert().accept();
			
		}

}
